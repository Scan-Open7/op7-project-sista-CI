<?php
class Detail_model extends CI_Model{
    public  $id;
    public  $penilain_id;
    public  $dosen_id;
    public  $seminar_id;
    public  $nilai;
    public  $view;

    public function getAll(){
        // Select * From Detail
        $query = $this->db->get('detail_penilaian');
        return $query;
    }
    public function findById($id){
        // Select * From Detail Where id=$id
        $query = $this->db->get_where('detail_penilaian',['id'=>$id]);
        return $query->row();
    }
}