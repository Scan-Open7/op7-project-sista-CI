<?php
class Dosen_model extends CI_Model
{

    //Mengambil Seluruh Data Tabel Dosen
    public function getAll()
    {
        //Select * From Dosen
        $query = $this->db->get('dosen');
        return $query;
    }

    //Mengambil Data Dosen Yang Memiliki $id tertentu
    public function findById($id)
    {
        //Select * From Dosen Where id=1;
        $query = $this->db->get_where('dosen', array('id' => $id));
        return $query->row();
    }
    public function simpan($data)
    {
        //Insert Into Dosen (nidn,nama) Values ('111','budi');
        $sql = "INSERT INTO dosen (nidn,nama) VALUES (?,?)";
        //$this->db->query($sql, array('111','budi'));
        $this->db->query($sql, $data);
    }
    public function update($data)
    {
        // Update Data Dosen SET nidn='1111', nama='budi s.Kom' Where id=1
        $sql = "UPDATE dosen SET nidn=?,nama=? WHERE id=?";
        $this->db->query($sql, $data);
    }
    public function delete($data)
    {
        $sql = "DELETE FROM dosen WHERE id=?";
        $this->db->query($sql, $data);
    }
}
