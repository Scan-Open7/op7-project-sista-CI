<?php
class Daftar_model extends CI_Model{

    //Mengambil Seluruh Data Tabel Dosen
    public function getAll(){
        //Select * From Daftar
        $query = $this->db->get('daftar');
        return $query;
    }

    //Mengambil Data Daftar Yang Memiliki $id tertentu
    public function findById($id){
        //Select * From Dosen Where id=1;
        $query = $this->db->get_where('daftar', array('id' => $id));
        return $query->row();
    }
    public function simpan($data){
        //Insert Into Dosen (nim,nama, email, alamat) Values ('111','budi', bu@gmail.com, Jakarta Barat);
        $sql = "INSERT INTO daftar (nim,nama,email,alamat) VALUES (?,?,?,?)";
        //$this->db->query($sql, array('111','budi'));
        $this->db->query($sql, $data);
    }
    public function update($data){
        // Update Data Dosen SET nidn='1111', nama='budi s.Kom' Where id=1
        $sql = "UPDATE daftar SET nim=?,nama=?, email=?, alamat=? WHERE id=?";
        $this->db->query($sql, $data);
    }
    public function delete($data){
        $sql = "DELETE FROM daftar WHERE id=?";
        $this->db->query($sql, $data);
    }
}