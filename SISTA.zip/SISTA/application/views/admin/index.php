<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <h3>Selamat Datang Admin SISTA!</h3>
    <h3>Hai, <?php echo $this->session->userdata("nama"); ?></h3>
    <a href="<?php echo base_url('index.php/login'); ?>">Logout</a>
</body>

</html>