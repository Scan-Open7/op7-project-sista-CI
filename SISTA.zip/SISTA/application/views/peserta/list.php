<table class="table">
<h3>Daftar Peserta</h3>
    <thead>
        <tr>
        <th>#</th><th>NIM</th><th>Nama</th><th>Seminar</th><th>Kehadiran</th><th>View</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor=1;
        foreach($peserta->result() as $peserta_seminar){
            echo'
            <tr>
                <td>'.$nomor.'</td>
                <td>'.$peserta_seminar->nim.'</td>
                <td>'.$peserta_seminar->nama.'</td>
                <td>'.$peserta_seminar->seminar_id.'</td>
                <td>'.$peserta_seminar->kehadiran.'</td>
                <td><ahref="'.base_url().'index.php/peserta/view/'.$peserta_seminar->id.'">view</a></td>
            </tr>';
            $nomor++;
        }
        ?>
    </tbody>
</table>