<table class="table">
<h3>Daftar Seminar</h3>
    <thead>
        <tr>
        <th>#</th><th>NIM</th><th>Nama</th><th>Semester</th><th>Kategori</th><th>Pembimbing</th><th>Penguji 1</th><th>Punguji 2</th><th>Tanggal</th><th>Waktu</th>
        <th>Materi Seminar</th><th>Lokasi</th><th>View</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor=1;
        foreach($seminar->result() as $seminar_ta){
            echo'
            <tr>
                <td>'.$nomor.'</td>
                <td>'.$seminar_ta->nim.'</td>
                <td>'.$seminar_ta->nama_mahasiswa.'</td>
                <td>'.$seminar_ta->semester.'</td>
                <td>'.$seminar_ta->kategori_seminar_id.'</td>
                <td>'.$seminar_ta->pembimbing_id.'</td>
                <td>'.$seminar_ta->penguji1_id.'</td>
                <td>'.$seminar_ta->penguji2_id.'</td>
                <td>'.$seminar_ta->tanggal.'</td>
                <td>'.$seminar_ta->jam.'</td>
                <td>'.$seminar_ta->judul.'</td>
                <td>'.$seminar_ta->lokasi.'</td>
                <td><ahref="'.base_url().'index.php/seminar/view/'.$seminar_ta->id.'">view</a></td>
            </tr>';
            $nomor++;
        }
        ?>
    </tbody>
</table>