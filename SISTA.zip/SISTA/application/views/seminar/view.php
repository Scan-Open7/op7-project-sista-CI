<h3>DataSeminar#ID:<?=$seminar_ta->id?></h3>
<div>
<tableclass="tabletable-striped">
    <tr>
        <td>NIM</td><td>:</td><td><?=$seminar_ta->nim?></td>
        <tr><td>Nama</td><td>:</td><td><?=$seminar_ta->nama_mahasiswa?></td></tr>
        <tr><td>Seminar</td><td>:</td><td><?=$seminar_ta->semester?></td></tr>
        <tr><td>Kategori</td><td>:</td><td><?=$seminar_ta->kategori_seminar_id?></td></tr>
        <tr><td>Pembimbing</td><td>:</td><td><?=$seminar_ta->pembimbing_id?></td></tr>
        <tr><td>Penguji 1</td><td>:</td><td><?=$seminar_ta->penguji1_id?></td></tr>
        <tr><td>Penguji 2</td><td>:</td><td><?=$seminar_ta->penguji2_id?></td></tr>
        <tr><td>Tanggal</td><td>:</td><td><?=$seminar_ta->tanggal?></td></tr>
        <tr>
            <td>Waktu</td><td>:</td><td><?=$seminar_ta->jam?></td>
        </tr>
        <tr>
            <td>Materi</td><td>:</td><td><?=$seminar_ta->judul?></td>
        </tr>
        <tr>
            <td>Lokasi</td><td>:</td><td><?=$seminar_ta->lokasi?></td>
        </tr>
    </tr>
</table>
</div>