<h3>DataPasien#ID:<?=$detail_penilaian->id?></h3>
<div>
<tableclass="tabletable-striped">
    <tr>
        <td>ID</td><td>:</td><td><?=$detail_penilaian->id?></td>
        <tr><td>Penilaian</td><td>:</td><td><?=$detail_penilaian->penilaian_id?></td></tr>
        <tr>
            <td>Nama Peserta</td><td>:</td><td><?=$detail_penilaian->detail_id?></td>
        </tr>
        <tr>
            <td>Seminar</td><td>:</td><td><?=$detail_penilaian->seminar_id?></td>
        </tr>
        <tr>
            <td>Nilai</td><td>:</td><td><?=$detail_penilaian->nilai?></td>
        </tr>
    </tr>
</table>
</div>