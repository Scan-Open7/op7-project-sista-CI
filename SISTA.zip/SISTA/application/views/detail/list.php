<table class="table">
<h3>Detail Nilai</h3>
    <thead>
        <tr>
        <th>#</th><th>ID</th><th>Penilaian</th><th>Dosen</th><th>Seminar</th><th>Nilai</th><th>View</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor=1;
        foreach($detail->result() as $detail_penilaian){
            echo'
            <tr>
                <td>'.$nomor.'</td>
                <td>'.$detail_penilaian->id.'</td>
                <td>'.$detail_penilaian->penilaian_id.'</td>
                <td>'.$detail_penilaian->dosen_id.'</td>
                <td>'.$detail_penilaian->seminar_id.'</td>
                <td>'.$detail_penilaian->nilai.'</td>
                <td><ahref="'.base_url().'index.php/detail/view/'.$detail_penilaian->id.'">view</a></td>
            </tr>';
            $nomor++;
        }
        ?>
    </tbody>
</table>