<table class="table">
    <h3>Data Nilai</h3>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="home/index">Home</a></li>
    <li class="breadcrumb-item"><a href="detail/list">List</a></li>
  </ol>
</nav>
    <thead>
        <tr>
            <th>#</th><th>ID</th><th>Penilaian</th><th>Nama Peserta</th><th>Seminar</th><th>Nilai</th>
        </tr>
    </thead>
    <tbody>
<?php
    $nomor=1;
    foreach($list_detail as $detail_penilaian){
?>
    <tr>
        <td><?=$nomor?></td>
        <td><?=$detail_penilaian->id?></td>
        <td><?=$detail_penilaian->penilaian_id?></td>
        <td><?=$detail_penilaian->dosen_id?></td>
        <td><?=$detail_penilaian->seminar_id?></td>
        <td><?=$detail_penilaian->nilai?></td>
    </tr>
<?php
    $nomor++;
}
?>
    </tbody>
</table>