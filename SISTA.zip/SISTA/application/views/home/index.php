<h3>Selamat Datang Di Sista!</h3>
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Pemrograman Web</h5>
        <p class="card-text">Pemrograman web dibuat dengan bahasa HTML, yaitu (Hyper text markup language). Bahasa HTML ini dikembangkan tim bernerslee pada saat mereka masih bekerja di CERN, perusahaan yang dikembangkan oleh NCSA pada tahun 1990 an.
                HTML diresmikan pada tahun 1995.</p>
        <a href="#" class="btn btn-primary">Next</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Jaringan Komputer</h5>
        <p class="card-text">Jaringan komputer adalah jaringan telekomunikasi yang memungkinkan antar komputer untuk saling 
          berkomunikasi dengan bertukar data. Tujuan dari jaringan komputer adalah agar dapat mencapai tujuannya, setiap 
          bagian dari jaringan komputer dapat meminta dan memberikan layanan.</p>
        <a href="#" class="btn btn-primary">Next</a>
      </div>
    </div>
  </div>
</div>
<br>
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Sistem Operasi</h5>
        <p class="card-text">Sistem operasi adalah perangkat lunak sistem yang mengatur sumber daya dari 
          perangkat keras dan perangkat lunak, serta sebagai daemon untuk program komputer.</p>
        <a href="#" class="btn btn-primary">Next</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">JavaScript</h5>
        <p class="card-text">JavaScript populer di internet dan dapat bekerja di sebagian besar penjelajah web populer seperti Google Chrome, 
          Internet Explorer, Mozilla Firefox, Netscape dan Opera.</p>
        <a href="#" class="btn btn-primary">Next</a>
      </div>
    </div>
  </div>
</div>
<br>
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Robotika</h5>
        <p class="card-text">Robotika adalah satu cabang teknologi yang berhubungan dengan desain, 
          konstruksi, operasi, disposisi struktural, pembuatan, dan aplikasi dari robot.</p>
        <a href="#" class="btn btn-primary">Next</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Statistik</h5>
        <p class="card-text">Statistika adalah sebuah ilmu yang mempelajari bagaimana cara merencanakan, mengumpulkan, menganalisis, 
          lalu menginterpretasikan, dan akhirnya mempresentasikan data.</p>
        <a href="#" class="btn btn-primary">Next</a>
      </div>
    </div>
  </div>
</div>