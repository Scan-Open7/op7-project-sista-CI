<h3>Data Profil Dosen</h3>

NIDN : <?= $objdosen->nidn ?>
<br />
Nama Lengkap : <?= $objdosen->nama ?>
<br />
<img src="<?= base_url() ?>uploads/photos/<?= $objdosen->nidn ?>.jpg" <?php echo $error; ?> <?php echo form_open_multipart('dosen/upload'); ?> <input type="file" name="foto" size="20" />
<?php echo $error; ?>
<input type="hidden" name="iddosen" value="<?= $objdosen->id ?>" />
<br /><br />
<input type="submit" value="upload" />
</form>