<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Seminar extends CI_Controller {
    public function index()
	{
		$this->load->model('seminar_model','seminar1');
		$this->seminar1->id=1;
		$this->seminar1->nim='0140088426';
		$this->seminar1->nama_mahasiswa='Dudin Hakim';
		$this->seminar1->semester='2';
		$this->seminar1->kategori_seminar_id='1';
		$this->seminar1->pembimbing_id='1';
		$this->seminar1->penguji1_id='1';
		$this->seminar1->penguji2_id='2';
		$this->seminar1->tanggal='05-10-2021';
		$this->seminar1->jam='08:30';
		$this->seminar1->judul='Jaringan Komputer';
		$this->seminar1->lokasi='B2 234, Jakarta Barat.';

		$this->load->model('seminar_model','seminar2');
		$this->seminar2->id=2;
		$this->seminar2->nim='0140088426';
		$this->seminar2->nama_mahasiswa='Nabila Salsabila';
		$this->seminar2->semester='3';
		$this->seminar2->kategori_seminar_id='1';
		$this->seminar2->pembimbing_id='1';
		$this->seminar2->penguji1_id='1';
		$this->seminar2->penguji2_id='2';
		$this->seminar2->tanggal='05-10-2021';
		$this->seminar2->jam='11:30';
		$this->seminar2->judul='Sistem Operasi';
		$this->seminar2->lokasi='B2 234, Jakarta Barat.';

		$this->load->model('seminar_model','seminar3');
		$this->seminar3->id=3;
		$this->seminar3->nim='0140088426';
		$this->seminar3->nama_mahasiswa='Muhammad Zaky';
		$this->seminar3->semester='5';
		$this->seminar3->kategori_seminar_id='1';
		$this->seminar3->pembimbing_id='1';
		$this->seminar3->penguji1_id='1';
		$this->seminar3->penguji2_id='2';
		$this->seminar3->tanggal='05-10-2021';
		$this->seminar3->jam='13:30';
		$this->seminar3->judul='Bahasa Inggris';
		$this->seminar3->lokasi='B2 234, Jakarta Barat.';

		$this->load->model('seminar_model','seminar4');
		$this->seminar4->id=4;
		$this->seminar4->nim='0140088426';
		$this->seminar4->nama_mahasiswa='Dea Wahyati';
		$this->seminar4->semester='4';
		$this->seminar4->kategori_seminar_id='1';
		$this->seminar4->pembimbing_id='1';
		$this->seminar4->penguji1_id='1';
		$this->seminar4->penguji2_id='2';
		$this->seminar4->tanggal='05-10-2021';
		$this->seminar4->jam='16:30';
		$this->seminar4->judul='Basis Data';
		$this->seminar4->lokasi='B2 234, Jakarta Barat.';

		$list_seminar=[$this->seminar1, $this->seminar2, $this->seminar3, $this->seminar4];
		$data['list_seminar']=$list_seminar;

		$this->load->view('header');
		$this->load->view('seminar/index', $data);
		$this->load->view('footer');
	}
	public function list(){
		$this->load->model('seminar_model');
		$data['seminar']=$this->seminar_model->getAll();

		$this->load->view('header');
		$this->load->view('seminar/list', $data);
		$this->load->view('footer');		
	}
	public function view($id){
		$this->load->model('seminar_model');
		$data['seminar']=$this->seminar_model->findById($id);

		$this->load->view('header');
		$this->load->view('seminar/view', $data);
		$this->load->view('footer');
	}
}