<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar extends CI_Controller {
    public function index()
	{
		$this->load->model('daftar_model','daftar');
		$data['list_daftar']=$this->daftar->getAll();

		$this->load->view('header');
		$this->load->view('daftar/index',$data);
		$this->load->view('footer');
	}
	public function create(){
		$data[]='';
		$this->load->view('header');
		$this->load->view('daftar/form',$data);
		$this->load->view('footer');
	}
	public function save(){
		$this->load->model('daftar_model','daftar');
		$_nim = $this->input->post('nim');
		$_nama = $this->input->post('nama');
		$_email = $this->input->post('email');
		$_alamat = $this->input->post('alamat');
		$_idedit = $this->input->post('idedit');

		$data_daftar['nim']=$_nim; // ? 1
		$data_daftar['nama']=$_nama; // ? 2
		$data_daftar['email']=$_email; // ? 3
		$data_daftar['alamat']=$_alamat;

		if(!empty($_idedit)){ // Update
			$data_daftar['id']=$_idedit; // ? 3
			$this->daftar->update($data_daftar);
		}else{ // Data Baru
			$this->daftar->simpan($data_daftar);
		}
		redirect('daftar','refresh');
	}
}