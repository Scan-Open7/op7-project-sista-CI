<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peserta extends CI_Controller {
    public function index()
	{
		$this->load->model('peserta_model','peserta1');
		$this->peserta1->id=1;
		$this->peserta1->nim='0111022746';
		$this->peserta1->nama='Budi Hakim';
		$this->peserta1->seminar_id='1';
		$this->peserta1->kehadiran='2';

		$this->load->model('peserta_model','peserta2');
		$this->peserta2->id=2;
		$this->peserta2->nim='0221032745';
		$this->peserta2->nama='Nabila Salsabila';
		$this->peserta2->seminar_id='2';
		$this->peserta2->kehadiran='2';

		$this->load->model('peserta_model','peserta3');
		$this->peserta3->id=3;
		$this->peserta3->nim='0291242744';
		$this->peserta3->nama='Zaky Nurohman';
		$this->peserta3->seminar_id='1';
		$this->peserta3->kehadiran='2';

		$this->load->model('peserta_model','peserta4');
		$this->peserta4->id=4;
		$this->peserta4->nim='0342055446';
		$this->peserta4->nama='Dea Wahyati';
		$this->peserta4->seminar_id='2';
		$this->peserta4->kehadiran='2';

		$this->load->model('peserta_model','peserta5');
		$this->peserta5->id=5;
		$this->peserta5->nim='0143322544';
		$this->peserta5->nama='Nabila Wahyati';
		$this->peserta5->seminar_id='3';
		$this->peserta5->kehadiran='2';

		$this->load->model('peserta_model','peserta6');
		$this->peserta6->id=4;
		$this->peserta6->nim='0140088426';
		$this->peserta6->nama='Zulkifri ALi';
		$this->peserta6->seminar_id='2';
		$this->peserta6->kehadiran='2';

		$list_peserta=[$this->peserta1, $this->peserta2, $this->peserta3, $this->peserta4, $this->peserta5, $this->peserta6];
		$data['list_peserta']=$list_peserta;

		$this->load->view('header');
		$this->load->view('peserta/index', $data);
		$this->load->view('footer');
	}
	public function list(){
		$this->load->model('peserta_model');
		$data['peserta']=$this->peserta_model->getAll();

		$this->load->view('header');
		$this->load->view('peserta/list', $data);
		$this->load->view('footer');		
	}
	public function view($id){
		$this->load->model('peserta_model');
		$data['peserta']=$this->peserta_model->findById($id);

		$this->load->view('header');
		$this->load->view('peserta/view', $data);
		$this->load->view('footer');
	}
}