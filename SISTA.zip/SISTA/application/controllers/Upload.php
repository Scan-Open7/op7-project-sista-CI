<?php
class Upload extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
    }
    public function index()
    {
        //$this->load->view('upload_form', array('error' => ''));
        $this->load->view('header');
        $this->load->view('dosen/view');
        $this->load->view('footer');
    }
}
